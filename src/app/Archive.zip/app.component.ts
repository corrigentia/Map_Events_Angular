import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `<app-menu></app-menu>`,
})
export class AppComponent {
  //title = 'COucou';
}
